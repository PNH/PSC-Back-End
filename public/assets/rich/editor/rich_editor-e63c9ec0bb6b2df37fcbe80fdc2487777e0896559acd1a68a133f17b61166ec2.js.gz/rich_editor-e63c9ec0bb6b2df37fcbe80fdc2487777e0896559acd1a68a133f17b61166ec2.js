// CKEditor plugin configuration

function addQueryString( url, params ) {
	var queryString = [];
	if (!params) return url;
	else {
		for (var i in params) queryString.push(i + "=" + encodeURIComponent( params[i]));
	}
	return url + ( ( url.indexOf( "?" ) != -1 ) ? "&" : "?" ) + queryString.join( "&" );
}

// Don't remove empty <i> tags so FontAwesome and similar icon fonts
// can be used in the editor without magically being stripped out
delete CKEDITOR.dtd.$removeEmpty['i'];
